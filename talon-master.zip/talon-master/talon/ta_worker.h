#ifndef __TA_WORKER_H_
#define __TA_WORKER_H_

#include "ta_misc.h"
#include "ta_conf.h"
#include "ta_http.h"

/**
 * 连接队列中的连接节点
 * 双向链表
 */
typedef struct tag_conn_node_t{
	struct tag_conn_node_t *previous;	// 前一个
	struct tag_conn_node_t *follow;		// 后一个
	ta_conn_t *conn;					// 连接
}ta_conn_node_t;


// 连接队列
typedef struct{
	ta_conn_node_t *front;		// 队列首
	ta_conn_node_t *rear;		// 队列尾
	ta_conn_node_t *buf;		// 队列数据区，实际上开的内存
	int cnt;					// 队列中的连接数量
}ta_conn_queue_t;



// worker进程的起点
void ta_worker_main();

// 处理超时连接
void ta_handle_expire_conn(ta_conn_queue_t *queue);

//临时测试用的
void proc_conn_tmp(ta_conn_t *conn);



#endif