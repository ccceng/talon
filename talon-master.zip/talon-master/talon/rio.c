#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#include <unistd.h>
#include <errno.h>
#include "rio.h"

static ssize_t rio_read(RIO *rp, char *usrbuf, size_t n);

/*
 * 非缓冲读取
 * 从fd中读n个字节到usrbuf
 * 可能读取不足
 * 
 * 关于被中断的read：
 *      System V实现为在未全部read要求的字节被中断时，read失败，返回-1
 *      BSD实现为read部分成功，返回已读字节数
 *      POSIX实现BSD的风格
 *      在一个阻塞的fd上执行该操作，会一直阻塞，直到读够要求字节
 */
ssize_t rio_readn(int fd, void *usrbuf, size_t n)
{
    size_t nleft = n;
    ssize_t nread;
    char *bufp = usrbuf;

    while (nleft > 0)
    {
        nread = read(fd, bufp, nleft);

        if ( nread < 0 )
        {
            if(errno == EINTR) // 被中断，一个字节都没读到
                continue;
            else
                return -1;  // read出错 
        }
        else if(nread == 0) // EOF
        {
            break;
        }
        nleft -= nread;
        bufp += nread;
    }
    return (n - nleft); // 返回已经读取的字节数
}

/*
 * 非缓冲写
 * 将usrbuf缓冲区中的前n个字节数据写入fd中
 * 该函数会保证n个字节都会写入fd中
 */
ssize_t rio_writen(int fd, void *usrbuf, size_t n)
{
    size_t nleft = n;
    ssize_t nwritten;
    char *bufp = (char *)usrbuf;

    while (nleft > 0) {
        if ((nwritten = write(fd, bufp, nleft)) <= 0)
        {
            if (errno == EINTR) // 被信号处理函数中断返回
            { 
                continue;
            }
            else    // write函数出错
            {
                return -1;
            }
        }
        nleft -= nwritten;
        bufp += nwritten;
    }
    return n;
}

/*
 * 初始化RIO结构
 * 用于实现带缓冲版本的读写
 * 类似于stdio中的FILE结构
 */
void rio_readinitb(RIO *rp, int fd)
{
    rp->rio_fd = fd;
    rp->rio_cnt = 0;
    rp->rio_bufptr = NULL;
}

/*
 * 系统调用read函数的优化
 * read每次读一个字节都要进行系统调用
 * rio_read会一次性读取多个字节填充内部缓冲区
 * 外界每次调用rio_read时实际上是从内部缓冲区中读取的，避免反复系统调用
 */
static ssize_t rio_read(RIO *rp, char *usrbuf, size_t n)
{
    int cnt;

    /**
     * 内部缓冲区为空，先填满缓冲区
     * 只要内部缓冲区为空，就一直执行填充操作，直到不为空
     */
    while (rp->rio_cnt <= 0)
    { 
        rp->rio_cnt = read(rp->rio_fd, rp->rio_buf, sizeof(rp->rio_buf));

        if (rp->rio_cnt < 0)   
        { 
            if (errno != EINTR)     // 非中断
            {   
                return -1;
            }
        }
        else if(rp->rio_cnt == 0)   // RIO类型的变量rp绑定的fd中达到EOF
        {
            return 0;
        }
        else 
        { 
            rp->rio_bufptr = rp->rio_buf;
        }
    }

    /**
     * 比较调用所需的字节数n与内部缓冲区可读字节数rp->rio_cnt
     * 取其中最小值
     * 
     * 假如被调用时，缓冲区中有数据，但未满，就不会触发填充缓冲区的操作
     * 因此一次rio_read调用最多读一个缓冲区那么多个字节
     */
    cnt = rp->rio_cnt < n ? rp->rio_cnt : n;
    memcpy(usrbuf, rp->rio_bufptr, cnt);
    rp->rio_bufptr += cnt;
    rp->rio_cnt -= cnt;
    return cnt;
}

/*
 * 缓冲版本readn
 * 从文件rp中读取n字节数据到usrbuf
 */
ssize_t rio_readnb(RIO *rp, void *usrbuf, size_t n)
{
    size_t nleft = n;
    ssize_t nread;
    char *bufp = usrbuf;

    while (nleft > 0)
    {
        nread = rio_read(rp, bufp, nleft);
        if ( nread < 0 )
        {
            if(errno == EINTR)  // 被中断
            {   
                // nread = 0;
                continue;
            }
            else    // 读取数据出错
            {
                return -1; 
            }
        }
        else if(nread == 0) // EOF
        {
            break; 
        } 
        nleft -= nread;
        bufp += nread;
    }
    return (n - nleft);
}


/*
 * 从文件rp中读取一行数据（包括结尾的换行符），拷贝到usrbuf
 * 最多读取maxlen - 1个字节
 * 并用0字符来结束这行数据
 * 返回读到的字节数
 */
ssize_t rio_readlineb(RIO *rp, void *usrbuf, size_t maxlen)
{
    int n, rc;
    char c, *bufp = usrbuf;

    for (n = 1; n < maxlen; n++)    // 最多读取maxlen - 1个字节
    {
        rc = rio_read(rp, &c, 1);
        if (rc == 1)
        {
            *bufp++ = c;
            if (c == '\n')  // 读完了一行
            {
                break;
            }
        }
        else if(rc == 0)    // EOF
        {
            if (n == 1) // EOF,但没有读取任何数据
            {
                return 0;
            }
            else    // EOF,但已经读取了一些数据
            {
                break;
            }
        }
        else    // 出错
        {
            return -1;
        }
    }

    *bufp = 0;  // 字符串0结尾
    return n;
}