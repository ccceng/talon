#ifndef __TA_HTTP_H_
#define __TA_HTTP_H_

#include "ta_misc.h"

// 定义的各种请求标志
#define HEAD 			1
#define GET 			2
#define POST 			4
#define PUT 			8
#define DELETE			16
#define CONNECT			32
#define OPTIONS			64
#define TRACE			128
#define UNIMPLEMENT		256		// 不支持该http方法
#define HTTP1_0			512		// http1.0
#define HTTP1_1			1024	// http1.1
#define HASPARM			4096	// 是否有参数
#define HASPOSTDATA		8192	// 是否有post数据
#define ENCTYPE_URLENCODED	2147483648	// post的编码格式为application/x-www-form-urlencoded，占用第31位
#define ENCTYPE_FORMDATA	1073741824	// post的编码格式为multipart/form-data	，占用第30位
#define	ENCTYPE_TEXTPLAIN	536870912	// post的编码格式为text/plain，占用第29位


// 定义的各种连接标志
#define	KEEPALIVE 		1	// 是否开启keep-alive
#define RECV_BLOCK		2   // 非阻塞情况下读将会阻塞
#define	SEND_BLOCK		4   // 非阻塞情况下写将会阻塞

// 定义的响应标志
#define USEINNERSTATUSCODEFILE	2147483648	// 使用程序内部硬编码的html（因为如404.html文件不存在，就用程序中硬编码的）



// 定义http状态吗
#define HTTP200 200
#define HTTP403 403
#define HTTP404 404
#define HTTP500 500


/**
 * 自定义缓冲区类型
 */
typedef struct {
	size_t cnt;
	ssize_t nleft;
	char *ptr;
	char data[BUFSIZE];
}ta_buf_t;


/**
 * 一个请求结构体
 */
typedef struct {
	char *method;
	char *url;
	char *version;
	char *host;
	char file[MAXLINE];		// 请求的文件，包括完整路径名
	char *useragent;
	char *parm;
	char *connection;
	char *content_type;
	int content_length;
	char *post_data;

	/**
	 * opt字段存放；
	 * 		http请求选项
	 *  	方法类型
	 *   	HTTP版本
	 *    	是否是Keep-Alive
	 *     	是否有参数
	 *      是否有post数据
	 */
	int opt;
	ta_buf_t buf;		// 用于接收请求数据的缓冲区
}ta_req_t;


/**
 * 一个响应结构体
 */
typedef struct{
	ta_buf_t buf;		// 用于发送数据的缓冲区
	char file[MAXLINE];	// 响应的文件，与请求的文件可能不同
	int opt;			// 记录响应的状态标志
	int code;	// http状态码
}ta_res_t;


/**
 * 一个连接结构体
 */
typedef struct {
	int fd;				// 描述符
	int expire;			// 连接超时时间戳（s精度）
	int read_linger;	// 读超时时间戳（ms精度）(暂时不考虑网络传输延时)
	int opt;			// 记录连接状态的
	int times;			// 连接接收的请求个数
	ta_req_t req;
	ta_res_t res;	
}ta_conn_t;


ta_conn_t *ta_make_conn(int acceptfd);
void ta_proc_conn(ta_conn_t *conn);

ssize_t ta_do_rcv(ta_conn_t *conn);
ssize_t ta_do_send(ta_conn_t *conn);

void ta_parse_req_line(ta_conn_t *conn);	// 解析请求行

void ta_parse_req_head(ta_conn_t *conn);	// 解析请求头部

// 按照后缀返回mime
char *ta_suffix2mime(char *suffix);

// 按照mime返回后缀
char *ta_mime2suffix(char *mime);

// http状态码对应的字符串
char *ta_http_code_string(int code);

// 服务器执行响应
void ta_response(ta_conn_t *conn);


/**
 * http响应
 */
void ta_res_send_data(ta_conn_t *conn);
void ta_res_head(ta_conn_t *conn);
void ta_prepare200(ta_conn_t *conn);
void ta_res400(ta_conn_t *conn);
void ta_prepare403(ta_conn_t *conn);
void ta_prepare404(ta_conn_t *conn);
void ta_prepare500(ta_conn_t *conn);


/**
 * 检查请求的文件
 * 返回相应的http状态码
 * 状态码属于定义的http状态码（200,404,403,500……）
 * @param conn [description]
 */
int ta_check_req_file(ta_conn_t *conn);

/**
 * 构建响应头部
 * @param conn [description]
 */
void ta_prepare_res_line(ta_conn_t *conn);
void ta_prepare_res_head(ta_conn_t *conn);

// 添加连接到队列
void ta_add_conn2queue(ta_conn_t *conn);

#endif