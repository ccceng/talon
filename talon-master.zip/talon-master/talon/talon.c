/**
 * talon
 * Author：yang
 */

#include <unistd.h>
#include <signal.h>
#include <sys/socket.h>
#include <sys/wait.h>
#include <netinet/in.h>
#include <arpa/inet.h>
#include <errno.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include "talon.h"

ta_conf_t conf;			// 配置信息变量
int listenfd;			// 监听套接字
struct sockaddr_in serveraddr;	//服务端地址
static pid_t *pids;		// 子进程数组，父进程kill子进程时会用到，记得退出时释放内存

#define DEBUG


/**
 * SIGINT信号处理程序
 * 关闭所有子进程
 */
static void sig_int(int signo)
{
	int i, serrno;
	
	serrno = errno;
	
	for(i = 0; i < conf.nps; i++)	// 向每条子进程发送SIGTERM要求退出
		kill(pids[i], SIGTERM);

	while( wait(NULL) > 0 );	// 回收子进程

	if(errno != ECHILD)
		ta_app_err("Master wait process error");
	
	free(pids);	// 释放内存
	errno = serrno;
	exit(EXIT_FAILURE);
}


/**
 * 父进程创建工作子进程
 * @return pid_t	返回子进程pid
 */
static pid_t make_worker()
{
	pid_t pid;
		
	if( (pid = fork()) < 0 )	// 创建子进程失败
	{	
		ta_unix_err("Fork failed during make worker");
	}
	else if( pid > 0 )
	{	// 父进程环境
		return (pid);
	}
	else if(pid == 0)	// 子进程环境
	{				
		ta_worker_main();	// 进入工作进程
	}
}

int main(int ac, char *av[])
{

	// 从配置文件中获取配置信息
	ta_file_conf("./conf/talon.conf", &conf);
	
	// 从cmd中获取配置信息
	ta_cmd_conf(ac, av, &conf);
	
	// ta_debug_conf(&conf);

	/**
	 * 安装信号处理程序
	 * 假如客户端过早关闭，那么第一次写入会正常返回，第二次写入就会发送SIGPIPE
	 * 默认会终止整个进程。假如捕获/忽略SIGPIPE，写操作返回-1，设置errno为EPIPE
	 * 忽略SIGPIPE
	 * SIGINT为关闭所有子进程，然后退出
	 */
	if( ta_signal(SIGPIPE, SIG_IGN) == SIG_ERR )
		ta_unix_err("Install SIGPIPE handler failed");
	
	if( ta_signal(SIGINT, sig_int) == SIG_ERR )
		ta_unix_err("Install SIGINT handler failed");
	
	// 创建监听套接字，非阻塞，linux才支持
	if( (listenfd = socket(AF_INET, SOCK_STREAM | SOCK_NONBLOCK, 0)) == -1 )
		ta_unix_err("Create listenfd failed");
	
#ifdef DEBUG
	int opt = 1;
	if( setsockopt(listenfd, SOL_SOCKET, SO_REUSEADDR, &opt, sizeof(int)) < 0)
		ta_unix_err("SO_REUSEADDR error");
#endif


	bzero(&serveraddr, sizeof(serveraddr));
	serveraddr.sin_family = AF_INET;
	serveraddr.sin_port = htons(conf.port);
	serveraddr.sin_addr.s_addr = htonl(INADDR_ANY);
	
	if( bind(listenfd, (struct sockaddr *)&serveraddr, sizeof(serveraddr)) == -1 )
		ta_unix_err("Bind error");
	if( listen(listenfd, MAXBACKLOG) == -1 )
		ta_unix_err("Listen error");
	
	
	/**
	 * 并发方式：
	 * 父进程创建子进程进行accept，随后父进程睡眠
	 * 为了避免子进程对监听套接字的竞争accept，采用文件加锁的方式在子进程间同步
	 * 文件锁在父进程中创建
	 */
	
	// 初始化accept锁
	ta_init_lock("/tmp/talon.XXXXXX");
	
	if( (pids = (pid_t *)calloc(conf.nps, sizeof(pid_t))) == NULL )
		ta_app_err("Calloc() failed for pids");
	
	// 创建子进程
	int i;
	for(i = 0; i < conf.nps; i++)
		pids[i] = make_worker();
	
	// 打印服务器信息
	struct sockaddr_in addrinfo;
	socklen_t ilen;
	char ipstr[INET_ADDRSTRLEN];
	ilen = sizeof(struct sockaddr_in);
	if( getsockname(listenfd, (struct sockaddr *)&addrinfo, &ilen) == -1 )
		ta_unix_err("getsockname()");
	if( inet_ntop(AF_INET, &addrinfo.sin_addr.s_addr, ipstr, INET_ADDRSTRLEN) == NULL )
		ta_unix_err("inet_ntop()");
	fprintf(stderr, "      ------ talon Server runs at %s:%d ------      \n", ipstr, conf.port);
	
	//睡眠
	while(1)
		pause();
}
