#ifndef __TA_MISC_H_
#define __TA_MISC_H_

/**
 * 下面定义的宏在整个工程中都会用到，要求每个文件都包含该头文件
 */
#define OPTSTRING	"p:n:hv"		// getopt()的参数字符串
#define MAXLINE 1024
#define MAXWORKER 16		// 最多产生16条工作子进程，防止用户在配置文件中随意指定
#define VERSION "0.0.1"		/* 当前版本 */
#define MAXBACKLOG 1024		// listen()函数的参数
#define INT(string) (*((int *)string))				// 把一个字符串按照int进行取值
#define DOUBLE(string) (*((double *)string))		// 把一个字符串按照double进行取值
#define MAXEVENT 64			// 一次epoll_wait调用能获取的最大事件数
#define BUFSIZE 8192		// 一个buf的大小,8KB
#define EXPIRE	5		// Connection: Keep-Alive的最大时间（s）
#define READLINGER	5	// 读套接字的最长时间(s)


typedef void(*sighandler_t)(int);


// 打印一条错误消息然后结束程序
void ta_app_err(const char *msg);

// 打印一条错误信息，获取errno错误码信息，然后退出
void ta_unix_err(const char *msg);


// 把字符串转换成大写
void ta_str2upper(char *str);

// 把字符串转换成小写
void ta_str2lower(char *str);

/* 自定义ta_signal函数，用sigaction实现，行为：
*	自我阻塞
*	自动重启系统调用
*	信号处理函数保持建立状态
*/
sighandler_t ta_signal(int sig, sighandler_t handler);



/**
 * 将整数转为字符串
 * 貌似库函数中没有
 */
char *ta_itoa(int n);

#endif