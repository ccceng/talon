#include <unistd.h>
#include <fcntl.h>
#include <errno.h>
#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#include "ta_lock.h"
#include "ta_misc.h"

static struct flock lock, unlock;
static int lockfd = -1;		// 用于加锁的临时文件描述符变量

/* 初始化accept互斥锁
 * 用一个临时文件，可以创建多个互斥锁
 */
void ta_init_lock(char *fpath)
{

	char lockfile[MAXLINE];
	
	bzero(lockfile, MAXLINE);
	strncpy(lockfile, fpath, sizeof(lockfile) - 1);
	
	if( (lockfd = mkstemp(lockfile)) == -1 )
		ta_unix_err("mkstemp()");
	if( unlink(lockfile) == -1 )
		ta_unix_err("unlink()");
	
	lock.l_type = F_WRLCK;
	lock.l_whence = SEEK_SET;
	lock.l_start = 0;
	lock.l_len = 0;		// 设置为0表示从起点到文件结尾加锁
	
	unlock.l_type = F_UNLCK;
	unlock.l_whence = SEEK_SET;
	unlock.l_start = 0;
	unlock.l_len = 0;
}


// 加锁，非阻塞，由调用者判断是否加锁成功
int ta_lock()
{
	return fcntl(lockfd, F_SETLK, &lock);
}

// 解锁
void ta_unlock()
{
	if( fcntl(lockfd, F_SETLK, &unlock) < 0 )
		ta_unix_err("fcntl error for unlock");
}

