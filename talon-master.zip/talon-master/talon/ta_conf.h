#ifndef __TA_CONF_H_
#define __TA_CONF_H_

#include "ta_misc.h"

// 配置选项结构体
typedef struct {
	char doc[MAXLINE];		// 主文档目录
	char cgi[MAXLINE];		// cgi目录
	int port;				// 端口
	int nps;				// 工作进程数量
}ta_conf_t;

// 从文件中读取配置
void ta_file_conf(char *fpath, ta_conf_t *cp);

// 从命令行读取配置
void ta_cmd_conf(int ac, char *av[], ta_conf_t *cp);

// 打印配置变量内容
void ta_debug_conf(ta_conf_t *cp);

#endif