#ifndef __TA_LOCK_H_
#define __TA_LOCK_H_

/* 初始化accept互斥锁
 * 用一个临时文件，可以创建多个锁
 */
void ta_init_lock(char *fpath);

// accept加锁
int ta_lock();

// accept解锁
void ta_unlock();

#endif