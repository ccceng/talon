#include <unistd.h>
#include <string.h>
#include <stdlib.h>
#include <stdio.h>
#include <errno.h>
#include <signal.h>
#include <ctype.h>
#include "ta_conf.h"
#include "ta_misc.h"

//把字符串转换成大写
void ta_str2upper(char *str)
{
	while(*str != '\0')
	{
		*str = toupper(*str);
		str++;
	}
}


//把字符串转换成小写
void ta_str2lower(char *str)
{
	while(*str != '\0')
	{
		*str = tolower(*str);
		str++;
	}
}

//打印一条错误消息然后结束程序
void ta_app_err(const char *msg)
{
	fprintf(stderr, "%s\n", msg);
	exit(EXIT_FAILURE);
}

// 打印一条错误信息，获取unix错误码，然后退出
void ta_unix_err(const char *msg)
{
	perror(msg);
	exit(EXIT_FAILURE);
}



/** 自定义ta_signal函数，用sigaction实现
 *	自我阻塞
 *	自动重启系统调用
 *	信号处理函数保持建立状态
 */
sighandler_t ta_signal(int sig, sighandler_t handler)
{
	struct sigaction act, oldact;
	
	act.sa_handler = handler;
	sigemptyset(&act.sa_mask);
	act.sa_flags = SA_RESTART | SA_RESETHAND;
	
	if( sigaction(sig, &act, &oldact) == -1)
		return (SIG_ERR);
	return oldact.sa_handler;	
}


/**
 * 将整数转为字符串
 * 貌似库函数中没有
 */
char *ta_itoa(int n)
{
	static char buf[11];

	bzero(buf, 11);
	sprintf(buf, "%d", n);
	return buf;
}