#include <unistd.h>
#include <fcntl.h>
#include <errno.h>
#include <string.h>
#include <stdlib.h>
#include <stdio.h>
#include <signal.h>
#include <sys/epoll.h>
#include <sys/stat.h>
#include <sys/socket.h>
#include <sys/types.h>
#include <sys/time.h>
#include <time.h>
#include <netinet/in.h>
#include <sys/sendfile.h>
#include "ta_worker.h"
#include "ta_conf.h"
#include "rio.h"
#include "ta_lock.h"
#include "ta_http.h"
#include "ta_misc.h"



#define _GNU_SOURCE		// 为了使用accept4()

extern ta_conf_t conf;	// 配置
extern int listenfd;	// 监听套接字
extern struct sockaddr_in serveraddr;	// 服务端sock地址
static struct epoll_event evlist[MAXEVENT];	// epoll事件
int efd;

static void sig_term(int signo);
void ta_add_to_epoll(int efd, ta_conn_t *conn, struct epoll_event *ev);
static void setopt(int fd);
void ta_proc_events(int efd);

// 连接队列
ta_conn_queue_t queue;

/**
 * 工作进程的起点
 * 首先安装信号SIGTERM处理程序
 * 创建epoll实例
 * while循环：
 * 		尝试获取锁
 *   	accept
 *    	释放锁
 *     	修改epoll监听队列
 *      epoll_wait
 *      处理连接
 * while循环
 * 进程意外、或收到SIGTERM退出
 */
void ta_worker_main()
{
	struct sockaddr_in clientaddr;
	socklen_t len = sizeof(struct sockaddr_in);
	int acceptfd;
	struct epoll_event ev;

	// 初始化连接队列
	queue.cnt = 0;
	queue.front = NULL;
	queue.rear = NULL;
	queue.buf = (ta_conn_node_t *)malloc(sizeof(ta_conn_node_t) * (int)sysconf(_SC_OPEN_MAX));
	if(queue.buf = NULL)
		ta_app_err("malloc() conn queue failed");

	if( ta_signal(SIGTERM, sig_term) == SIG_ERR )
		ta_unix_err("Install SIGTERM handler failed");
	
	// 创建epoll实例
	if( (efd = epoll_create( (int)sysconf(_SC_OPEN_MAX) )) == -1 )
		ta_unix_err("epoll_create()");

	// 进入主循环，开始接受请求
	bzero(&ev, sizeof(struct epoll_event));
	fprintf(stderr, "Worker pid = %d\n", getpid());
	while(1)
	{
		// 处理超时
		// ta_handle_expire_conn(&queue);
		
		//获得锁
		if( ta_lock() != -1 )	// 成功获取锁
		{
			acceptfd = accept4(listenfd, (struct sockaddr *)&clientaddr, &len, SOCK_NONBLOCK);
			//
			// acceptfd = accept(listenfd, (struct sockaddr *)&clientaddr, &len);
			ta_unlock();	// 释放锁

			/**
			 * If no pending connections are present on the queue, 
			 * and the socket is not marked as non-blocking,
			 * accept() blocks the caller until a connection is present.
			 * ------------------------------------------------------------------------
			 * If the socket is marked non-blocking and no pending connections are present on the queue,
			 * accept() fails with the error EAGAIN or EWOULDBLOCK.
			 */
			
			if(acceptfd != -1)	// accept得到一个客户端套接字，这里没有处理错误，和没有客户端的情况
			{
				// setopt(acceptfd);	// 设置套接字选项
				ta_conn_t *conn = ta_make_conn(acceptfd);
				if(conn)
				{
					ev.data.ptr = (void *)conn;
					ev.events =  EPOLLIN | EPOLLET;
					ta_add_to_epoll(efd, conn, &ev);	// 将accept的fd生成的连接添加进epoll监控列表		
				}
				else
				{
					close(acceptfd);
				}
			}
		}
		ta_proc_events(efd);	// 处理epoll事件
	}
}


/* 处理epoll事件
 * 这里需要用到第一步获得的超时时间
 * 进行计时epoll_wait
 */
void ta_proc_events(int efd)
{
	int n, i;
	int readyfd;
	ta_conn_t *conn;

	n = epoll_wait(efd, evlist, MAXEVENT, 10);	// 执行一次检查
	
	i = 0;	
	while( n-- > 0 )
	{
		conn = (ta_conn_t *)evlist[i].data.ptr;
		readyfd = conn->fd;
		
		if( evlist[i].events & EPOLLIN )
		{
			// proc_conn_tmp(conn);
			ta_proc_conn(conn);		
		}
		else
		{
			epoll_ctl(efd, EPOLL_CTL_DEL, readyfd, NULL);
			close(readyfd);
			free(conn);
		}
		i++;
	}
}


/**
 * 工作进程处理SIGTERM信号
 * @int signo 信号
 */
static void sig_term(int signo)
{
	int serrno = errno;
	
	/**
	 * TODO：
	 * 执行子进程退出时的收尾工作
	 */
	
	fprintf(stderr, "Worker %d exit\n", getpid());

	errno = serrno;

	exit(EXIT_SUCCESS);
}


/**
 * 将一个conn添加到epoll实例的监听队列中
 * @int efd			epoll实例
 * @ta_conn_t *		要添加到epoll实例的连接（实际上是添加连接中的fd）
 * @struct epoll_event* ev 	一个epoll事件选项
 */
void ta_add_to_epoll(int efd, ta_conn_t *conn, struct epoll_event *ev)
{
	if( epoll_ctl(efd, EPOLL_CTL_ADD, conn->fd, ev) == -1 )	// 注册失败
		close(conn->fd);	// 关掉该客户端套接字
}

/**
 * 设置套接字选项
 * 这里主要是将套接字的接受低水位标记设置为16字节
 * @param fd
 */
static void setopt(int fd)
{
	int optval = 16;

	setsockopt(fd, SOL_SOCKET, SO_RCVLOWAT, &optval, sizeof(int));
}


//临时测试用的
void proc_conn_tmp(ta_conn_t *conn)
{
	static int count = 0;
	char res_header[MAXLINE], req_buf[MAXLINE];
	struct stat stat;
	int readyfd, fd;

	readyfd = conn->fd;	
	bzero(res_header, MAXLINE);
	snprintf(res_header, MAXLINE - 1, "HTTP/1.1 200 OK\r\n"
							"Server: talon Server "VERSION"\r\n"
							"Content-Type: text/html\r\n"
							"PID: %d\r\n"
							"Content-Length: %d\r\n\r\n", getpid(), (int)stat.st_size);
							
	fd = open("./www/test.html", O_RDONLY);
	fstat(fd, &stat);

	bzero(req_buf, MAXLINE);
	rio_readn(readyfd, req_buf, MAXLINE - 1);
	// read(readyfd, req_buf, MAXLINE - 1);
	printf("pid/%d - %d\n", getpid(), ++count);
	printf("%s", req_buf);

	rio_writen(readyfd, res_header, strlen(res_header));
	lseek(fd, 0, SEEK_SET);
	sendfile(readyfd, fd, NULL, stat.st_size);
	shutdown(readyfd, SHUT_WR);
	close(readyfd);
}


/**
 * 生成一个文件描述符为fd的请求结构体
 * @param  fd 请求文件描述符
 * @return ta_conn_t *	成功返回一个指向请求结构体的指针，失败返回NULL
 */
ta_conn_t *ta_make_conn(int acceptfd)
{
	ta_conn_t *conn;

	conn = (ta_conn_t *)malloc(sizeof(ta_conn_t));
	if(conn == NULL)
		return NULL;
	bzero(conn, sizeof(ta_conn_t));		// 将连接对象内存置零
	conn->fd = acceptfd;
	return conn;
}

/**
 * [ta_proc_conn description]
 * @param conn [description]
 */
void ta_proc_conn(ta_conn_t *conn)
{
	ssize_t nrcv, nsend;

	nrcv = ta_do_rcv(conn);

	// 处理请求数据
	if(nrcv != -1)
	{
		ta_parse_req_line(conn);	// 解析请求行
		ta_parse_req_head(conn);	// 解析请求头部
		ta_response(conn);
	}	
}

// 处理超时连接
void ta_handle_expire_conn(ta_conn_queue_t *queue)
{
	ta_conn_node_t *nodep;	// 连接队列中的一个节点
	time_t timestamp;

	if(queue->cnt <= 0)
		return;

	nodep = queue->front;
	queue->front = nodep->follow;
	queue->cnt--;
	timestamp = time(NULL);
	if(nodep->conn->expire > timestamp)
	{
		shutdown(nodep->conn->fd, SHUT_WR);
		close(nodep->conn->fd);	// 不用释放内存，把数据清空就可以了
		bzero(nodep, sizeof(ta_conn_node_t));
	}

}