#ifndef __RIO_H_
#define __RIO_H_

/**
 * 来自CSAPP的RIO
 */


#define RIO_BUFSIZE 8192

/**
 * 自定义的RIO数据类型
 * 实现带缓冲的读取
 * 将一个文件描述符和一个内部缓冲区关联
 * 相当于stdio中的FILE类型
 */
typedef struct {
    int rio_fd;                 // 关联的fd
    int rio_cnt;                // 剩余字节数
    char *rio_bufptr;           // 下一个可读字节
    char rio_buf[RIO_BUFSIZE];  // 缓冲区
} RIO;

ssize_t rio_readn(int fd, void *usrbuf, size_t n);
ssize_t rio_writen(int fd, void *usrbuf, size_t n);
void rio_readinitb(RIO *rp, int fd);
ssize_t rio_readlineb(RIO *rp, void *usrbuf, size_t maxlen);
ssize_t rio_readnb(RIO *rp, void *usrbuf, size_t n);

#endif
