#include <unistd.h>
#include <sys/stat.h>
#include <sys/types.h>
#include <sys/socket.h>
#include <sys/epoll.h>
#include <sys/mman.h>
#include <fcntl.h>
#include <errno.h>
#include <string.h>
#include <stdlib.h>
#include <stdio.h>
#include <signal.h>
#include <ctype.h>
#include <time.h>
#include <sys/sendfile.h>

#include "ta_http.h"
#include "ta_conf.h"
#include "ta_misc.h"
#include "ta_worker.h"
#include "rio.h"

#define ISSPACE(x)		((x) == ' ' || (x) == '\t')
#define ISNEWLINE(x)		((x) == '\r' || (x) == '\n')
extern ta_conf_t conf;	// 配置，进程中的全局变量，在talon.c中定义的

static char *HTTP404_STRING = "<!DOCTYPE html><html><head><title>404 Not Found</title></head><body><h2>404 Not Found</h2><hr/><p><i>Talon Server - "VERSION"</i></p></html>";
static char *HTTP403_STRING = "<!DOCTYPE html><html><head><title>403 Forbidden</title></head><body><h2>403 Forbidden</h2><hr/><p><i>Talon Server - "VERSION"</i></p></body></html>";
static char *HTTP500_STRING = "<!DOCTYPE html><html><head><title>500 Internal Server Error</title></head><body><h2>500 Internal Server Errorn</h2><hr/><p><i>Talon Server - "VERSION"</i></p></body></html>";

extern ta_conn_queue_t queue;
extern int efd;

/**
 * 判断http状态码文件是否存在，如404.html，500.html等
 * 存在返回文件名（包括路径）
 * 不存在返回NULL
 * @param  code [description]
 * @return      [description]
 */
static char *http_status_code_file(int code)
{
	static char buf[MAXLINE];
	struct stat fstat;

	bzero(buf, MAXLINE);
	strcpy(buf, conf.doc);
	strcat(buf, "/");
	strcat(buf, ta_itoa(code));
	strcat(buf, ".html");
	if(stat(buf, &fstat) == -1)
		return NULL;
	return buf;
}

// 服务器执行响应
void ta_response(ta_conn_t *conn)
{
	int status_code;

	ta_prepare_res_line(conn);
	ta_prepare_res_head(conn);

	// 根据不同的响应码做响应
	ta_res_send_data(conn);

/*	
	// 处理Keep-Alive
	if(conn->opt & KEEPALIVE)
	{
		// 添加连接到队列
		ta_add_conn2queue(conn);
	}
	else
	{
		shutdown(conn->fd, SHUT_WR);
		close(conn->fd);
		free(conn);
	}

	*/

	shutdown(conn->fd, SHUT_WR);
	epoll_ctl(efd, EPOLL_CTL_DEL, conn->fd, NULL);
	close(conn->fd);
	free(conn);
}

void ta_prepare_res_line(ta_conn_t *conn)
{

	// 修改res.file，res.code，返回http code
	ta_check_req_file(conn);

	strcpy(conn->res.buf.data, conn->req.version);
	strcat(conn->res.buf.data, ta_http_code_string(conn->res.code));
}

void ta_prepare_res_head(ta_conn_t *conn)
{
		
	time_t timestamp;
	struct tm *gmtm;
	char *timestr;
	char *suffix;

	// GMT时间字符串
	time(&timestamp);
	gmtm = gmtime(&timestamp);
	timestr = asctime(gmtm);

	// 获取响应文件的后缀
	suffix = conn->res.file;
	suffix = suffix + strlen(suffix) - 1;
	while(*suffix != '.')
		suffix--;

	strcat(conn->res.buf.data, "Date: ");
	strcat(conn->res.buf.data ,timestr);
	strcat(conn->res.buf.data, " GMT\r\n"
			"Server: Talon/"VERSION"\r\n"
			"Content-Type: ");
	suffix = ta_suffix2mime(suffix);
	strcat(conn->res.buf.data, suffix);
	if(*suffix == 't')
		strcat(conn->res.buf.data, "; charset=utf-8\r\n");
	else
		strcat(conn->res.buf.data, "\r\n");

	// 保持连接
	// if(conn->opt & KEEPALIVE)
	// {
	// 	strcat(conn->res.buf.data, "Connection: Keep-Alive\r\n"
	// 								"Keep-Alive: timeout=");
	// 	strcat(conn->res.buf.data, ta_itoa(EXPIRE));
	// 	strcat(conn->res.buf.data, ", max=100\r\n");
	// }

	strcat(conn->res.buf.data, "Connection: Close\r\n");

	// 使用硬编码的html,把硬编码的数据直接拷如响应缓冲区中
	// 磁盘上的文件用sendfile()发送
	if(conn->res.opt & USEINNERSTATUSCODEFILE)		
	{
		strcat(conn->res.buf.data, "Content-Length: ");
		switch(conn->res.code)
		{
			case HTTP403:
				strcat(conn->res.buf.data, ta_itoa(strlen(HTTP403_STRING)));
				strcat(conn->res.buf.data, "\r\n\r\n");
				strcat(conn->res.buf.data, HTTP403_STRING);
				break;
			case HTTP404:
				strcat(conn->res.buf.data, ta_itoa(strlen(HTTP404_STRING)));
				strcat(conn->res.buf.data, "\r\n\r\n");
				strcat(conn->res.buf.data, HTTP404_STRING);
				break;
			case HTTP500:
				strcat(conn->res.buf.data, ta_itoa(strlen(HTTP500_STRING)));
				strcat(conn->res.buf.data, "\r\n\r\n");
				strcat(conn->res.buf.data, HTTP500_STRING);
				break;
		}
		return;	// 提前返回
	}

	// 磁盘上的文件
	struct stat fstat;
	stat(conn->res.file, &fstat);
	strcat(conn->res.buf.data, "Content-Length: ");
	strcat(conn->res.buf.data, ta_itoa(fstat.st_size));
	strcat(conn->res.buf.data, "\r\n\r\n");
}


// 根据不同的响应码做响应
void ta_res_send_data(ta_conn_t *conn)
{
	int fd;
	char *srcp;

	ta_do_send(conn);

	if( !(conn->res.opt & USEINNERSTATUSCODEFILE) )
	{
		int fd;
		struct stat file_stat;
		fd = open(conn->res.file, O_RDONLY);
		fstat(fd, &file_stat);
		while( sendfile(conn->fd, fd, NULL, file_stat.st_size) == -1 );
		// srcp = mmap(0, file_stat.st_size, PROT_READ, MAP_PRIVATE, fd, 0);
		// rio_writen(conn->fd, srcp, file_stat.st_size);  
		// munmap(srcp, file_stat.st_size);
		close(fd);
	}
}


// 执行连接的写入操作
ssize_t ta_do_send(ta_conn_t *conn)
{
    ssize_t nwritten;
    size_t nleft;

    char *bufp = (char *)conn->res.buf.data;

    nleft = conn->res.buf.cnt = strlen(conn->res.buf.data);
    while (nleft > 0) {
        if ((nwritten = send(conn->fd, bufp, nleft, 0)) <= 0)
        {
            if (errno == EINTR) // 被信号处理函数中断返回
            { 
                continue;
            }
            else    // write函数出错
            {
                return -1;
            }
        }
        nleft -= nwritten;
        bufp += nwritten;
    }
    return conn->res.buf.cnt;
}

/**
 * 执行从连接中读数据到连接的读缓冲区
 * @ta_conn_t	conn 连接指针
 * @return	ssize_t  成功返回读到的字节数，失败返回-1
 */
ssize_t ta_do_rcv(ta_conn_t *conn)
{
	ssize_t nrcv;

	// // 记着这里，每次读数据都将缓冲区清空了
	// // 非阻塞，数据部分接收时会有严重错误。。。数据不全。。。
	// bzero(conn->req.buf.data, BUFSIZE);
	// conn->req.buf.cnt = 0;
	// conn->req.buf.ptr = NULL;

	// nrcv = recv(conn->fd, conn->req.buf.data + conn->req.buf.cnt, BUFSIZE - conn->req.buf.cnt, MSG_DONTWAIT);
	nrcv = recv(conn->fd, conn->req.buf.data, BUFSIZE, MSG_DONTWAIT);
	if(nrcv == -1)
	{
		if(errno == EAGAIN)
		{
			conn->opt |= RECV_BLOCK;
			return -1;
		}
	}
	// conn->req.buf.cnt += nrcv;
	// conn->req.buf.nleft += nrcv;
	// conn->req.buf.ptr = conn->req.buf.data + (conn->req.buf.cnt - conn->req.buf.nleft);
	
	conn->req.buf.cnt = nrcv;
	conn->req.buf.ptr = conn->req.buf.data;
	return nrcv;
}


/**
 * 解析请求行
 * @param conn [description]
 */
void ta_parse_req_line(ta_conn_t *conn)
{
	char *pos;
	char *cur;
	int val;
	char c;

	/*********** 开始解析http方法 ****************/
	pos = conn->req.buf.ptr;
	while(ISSPACE(*pos))
		pos++;
	conn->req.method = pos;
	while( !ISSPACE(*pos) )
		pos++;
	*pos = '\0';
	pos++;	// 前进一步
	if(!strcasecmp(conn->req.method, "GET"))
		conn->req.opt |= GET;
	else if(!strcasecmp(conn->req.method, "POST"))
		conn->req.opt |= POST;
	else if(!strcasecmp(conn->req.method, "HEAD"))
		conn->req.opt |= HEAD;	
	else if(!strcasecmp(conn->req.method, "PUT"))
		conn->req.opt |= PUT;	
	else if(!strcasecmp(conn->req.method, "DELETE"))
		conn->req.opt |= DELETE;	
	else if(!strcasecmp(conn->req.method, "OPTIONS"))
		conn->req.opt |= OPTIONS;
	else if(!strcasecmp(conn->req.method, "CONNECT"))
		conn->req.opt |= CONNECT;
	else if(!strcasecmp(conn->req.method, "TRACE"))
		conn->req.opt |= TRACE;
	else
		conn->req.opt |= UNIMPLEMENT;
	/*********** 解析http方法完成 ****************/

	/*********** 开始解析url ****************/
	/**
	 * 处理url中的转义字符、空格
	 * 将类似“/adasd/.././../index.html”这样的url中的../和./去掉
	 */
	while(ISSPACE(*pos))
		pos++;
	conn->req.url = pos;
	cur = pos;
	while(!ISSPACE(*pos))
	{
		if(*pos == '+')
		{
			*pos = ' ';
			pos++;
			cur++;
			continue;
		}
		else if(*pos == '%' && isxdigit(*(pos + 1)) && isxdigit(*(pos + 2)))
		{
			val = 0;
			c = *(pos + 1);	// 解析第一位
			if(c < 58)
				val = (c - 48) << 4;
			else if(c >= 65 && c <= 70)	// 实际上，ascii码第一位不会出现大于7的字符
				val = (c - 55) << 4;
			else
				val = (c - 87) << 4;

			c = *(pos + 2);	// 解析第二位
			if(c < 58)
				val = val + (c - 48);
			else if(c >= 65 && c <= 70)	// 实际上，ascii码第一位不会出现大于7的字符
				val = val + (c - 55);
			else
				val = val + (c - 87);

			*cur = (char)val;
			pos = pos + 3;
			cur++;
			continue;
		}
		else if(*pos == '.' && *(pos + 1) == '/')
		{
			pos = pos + 2;
			continue;
		}
		else if(*pos == '.' && *(pos + 1) == '.' && *(pos + 2) == '/')
		{
			pos = pos + 3;
			continue;
		}
		else if(*pos == '?' && !ISSPACE(*(pos + 1)))
		{
			*pos = '\0';
			conn->req.parm = pos + 1;
			conn->req.opt |= HASPARM;
			break;
		}

		*cur = *pos;
		cur++;
		pos++;
	}
	*cur = '\0';
	*pos = '\0';
	pos++;	// 前进一步
	if(conn->req.opt & HASPARM)	// 该请求有查询参数
	{
		while(!ISSPACE(*pos))		// 将查询参数的结尾找出来
			pos++;
		*pos = '\0';
		pos++;
	}

	/***************** url解析完成 ************/

	/*********** 开始解析http版本 ************/
	while(ISSPACE(*pos))
		pos++;
	conn->req.version = pos;
	while(!ISSPACE(*pos) && !ISNEWLINE(*pos))
		pos++;
	*pos = '\0';
	if(!strcasecmp(conn->req.version, "HTTP/1.1"))
	{
		conn->req.opt |= HTTP1_1;
		conn->opt |= KEEPALIVE;
		conn->expire = EXPIRE;	// 过期时间为5000ms，在ta_misc.h中定义的宏
	}	
	else
	{
		// 这里只是将选项中的标记设置为了http1.0，但是接收的字符串内容没有改变
		conn->req.opt |= HTTP1_0;	// 默认按照http1.0处理
	}
	/*********** 完成http版本解析 ****************/

	pos++;
	while(ISNEWLINE(*pos))
		pos++;
	conn->req.buf.ptr = pos;

	// printf("%s\n", conn->req.method);
	// printf("%s\n", conn->req.url);
	// printf("%s\n", conn->req.version);
	// printf("%s\n", conn->req.parm);
}


/**
 * 解析请求头部
 * @param conn [description]
 */
void ta_parse_req_head(ta_conn_t *conn)
{
	char *pos;
	char *khead;	// key的头指针（http报文头部看做键值对）
	char *vhead;	// value的头指针

	pos = conn->req.buf.ptr;
	while(1)
	{
		if((*pos == '\r') && (*(pos + 1) == '\n'))	// 跳出循环，此时pos位于空白行
			break;
		khead = pos;
		while(*pos != ':')
			pos++;
		*pos = '\0';
		pos++;
		while(ISSPACE(*pos))
			pos++;
		vhead = pos;
		while(!ISNEWLINE(*pos))
			pos++;
		*pos = '\0';
		pos = pos + 2;	//跳到下一行

		if(!strcasecmp(khead, "Host"))	// Host头
			conn->req.host = vhead;
		else if(!strcasecmp(khead, "User-Agent"))	// User-Agent头
			conn->req.useragent = vhead;
		else if(!strcasecmp(khead, "Connection"))	// Connection头
		{
			conn->req.connection = vhead;
			if(!strcasecmp(vhead, "Keep-Alive"))	// 保持连接
				conn->opt |= KEEPALIVE;
			else if(!strcasecmp(vhead, "Close"))
				conn->opt &= ~KEEPALIVE;
		}
		else if(!strcasecmp(khead, "Content-Type"))
		{
			conn->req.content_type = vhead;
			conn->req.opt |= HASPOSTDATA;	// 该请求有POST数据
			if(!strcasecmp(vhead, "application/x-www-form-urlencoded"))
				conn->req.opt |= ENCTYPE_URLENCODED;
			else if(!strcasecmp(vhead, "multipart/form-data"))
				conn->req.opt |= ENCTYPE_FORMDATA;
			else if(!strcasecmp(vhead, "text/plain"))
				conn->req.opt |= ENCTYPE_TEXTPLAIN;
		}
		else if(!strcasecmp(khead, "Content-Length"))
		{
			conn->req.opt |= HASPOSTDATA;	// 该请求有POST数据
			conn->req.content_length = atoi(vhead);
		}
	}

	conn->req.buf.ptr = pos + 2;	// 假如有post数据，此时ptr位于数据的第一个字节上，否则，位于末尾

	if(conn->req.opt & HASPOSTDATA && 
		(conn->req.opt & ENCTYPE_URLENCODED || 
			conn->req.opt & ENCTYPE_TEXTPLAIN))	// 暂时不考虑multipart/form-data
	{
		conn->req.post_data = conn->req.buf.ptr;
	}
}


// 后缀返回mime
char *ta_suffix2mime(char *suffix)
{
	static char buf[128];

	if(!strcasecmp(suffix, ".html") || !strcasecmp(suffix, ".htm"))
		strcpy(buf, "text/html");
	else if(!strcasecmp(suffix, ".js"))
		strcpy(buf, "text/javascript");
	else  if(!strcasecmp(suffix, ".css"))
		strcpy(buf, "text/css");
	else if(!strcasecmp(suffix, ".xhtml"))
		strcpy(buf, "application/xhtml+xml");
	else if(!strcasecmp(suffix, ".ico"))
		strcpy(buf, "image/x-icon");
	else if(!strcasecmp(suffix, ".jpg") || !strcasecmp(suffix, "jpeg") || !strcasecmp(suffix, "jpe"))
		strcpy(buf, "image/jpeg");
	else if(!strcasecmp(suffix, ".png"))
		strcpy(buf, "image/png");
	else if(!strcasecmp(suffix, ".gif"))
		strcpy(buf, "image/gif");
	else if(!strcasecmp(suffix, ".bmp"))
		strcpy(buf, "image/bmp");
	else if(!strcasecmp(suffix, ".tif") || !strcasecmp(suffix, ".tiff"))
		strcpy(buf, "image/tiff");
	else if(!strcasecmp(suffix, ".xml"))
		strcpy(buf, "text/xml");
	else if(!strcasecmp(suffix, ".txt"))
		strcpy(buf, "test/plain");
	else if(!strcasecmp(suffix, ".json"))
		strcpy(buf, "application/json");
	else if(!strcasecmp(suffix, ".mp3"))
		strcpy(buf, "audio/mpeg");
	else if(!strcasecmp(suffix, ".wav"))
		strcpy(buf, "audio/wav");
	else if(!strcasecmp(suffix, ".wma"))
		strcpy(buf, "audio/x-ms-wma");
	else if(!strcasecmp(suffix, ".mid"))
		strcpy(buf, "audio/mid");
	else if(!strcasecmp(suffix, ".mpg") || !strcasecmp(suffix, ".mpeg"))
		strcpy(buf, "video/mpeg");
	else if(!strcasecmp(suffix, ".mp4"))
		strcpy(buf, "video/mp4");
	else if(!strcasecmp(suffix, ".rmvb"))
		strcpy(buf, "audio/x-pn-realaudio");
	else if(!strcasecmp(suffix, ".avi"))
		strcpy(buf, "video/x-msvideo");
	else if(!strcasecmp(suffix, ".gz"))
		strcpy(buf, "application/x-gzip");
	else if(!strcasecmp(suffix, ".tar"))
		strcpy(buf, "application/x-tar");
	else if(!strcasecmp(suffix, ".zip"))
		strcpy(buf, "application/zip");
	else if(!strcasecmp(suffix, ".rar"))
		strcpy(buf, "application/octet-stream");
	else if(!strcasecmp(suffix, ".doc"))
		strcpy(buf, "application/msword");
	else if(!strcasecmp(suffix, ".rtf"))
		strcpy(buf, "application/rtf");
	else if(!strcasecmp(suffix, ".docx"))
		strcpy(buf, "application/vnd.openxmlformats-officedocument.wordprocessingml.document");
	else if(!strcasecmp(suffix, ".pdf"))
		strcpy(buf, "application/pdf");
	else if(!strcasecmp(suffix, ".xls") || !strcasecmp(suffix, ".xlm"))
		strcpy(buf, "application/vnd.ms-excel");
	else if(!strcasecmp(suffix, ".xlsx"))
		strcpy(buf, "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet");

	return buf;
}

// mime返回后缀
char *ta_mime2suffix(char *mime)
{

}

/**
 * 检查请求的文件
 * 返回相应的http状态码
 * 状态码属于定义的http状态码（200,404,403,500……）
 * @param conn [description]
 */
int ta_check_req_file(ta_conn_t *conn)
{
	char *pos;
	struct stat fstat;
	char *req_file;
	char *res_file;
	char *tmp;
	int ret;

	// 首先构建请求文件
	req_file = conn->req.file;
	res_file = conn->res.file;
	pos = conn->req.url;
	while(*pos)
		pos++;
	pos--;
	if(*pos == '/')
	{
		strcpy(req_file, conf.doc);
		strcat(req_file, "/index.html");
	}
	else
	{
		strcpy(req_file, conf.doc);
		strcat(req_file, conn->req.url);
	}

	// 然后看请求的文件是否存在
	if( (ret = stat(req_file, &fstat)) == 0)
	{
		conn->res.code = HTTP200;
		strcpy(res_file, req_file);
	}
	else if(ret == -1)
	{
		if(errno == EACCES)
		{
			conn->res.code = HTTP403;
			if( (tmp = http_status_code_file(HTTP403)) )
				strcpy(res_file, tmp);
			else
				conn->res.opt |= USEINNERSTATUSCODEFILE;

		}
		else if(errno == ENOENT)
		{
			conn->res.code = HTTP404;
			if( (tmp = http_status_code_file(HTTP404)) )
				strcpy(res_file, tmp);
			else
				conn->res.opt |= USEINNERSTATUSCODEFILE;
		}
		else
		{
			conn->res.code = HTTP500;
			if( (tmp = http_status_code_file(HTTP500)) )
				strcpy(res_file, tmp);
			else
				conn->res.opt |= USEINNERSTATUSCODEFILE;
		}
	}
	return conn->res.code;
}


// http状态码对应的字符串
char *ta_http_code_string(int code)
{
	static char buf[64];

	switch(code)
	{
		case 200:
			strcpy(buf, " 200 OK\r\n");
			break;
		case 403:
			strcpy(buf, " 403 Forbidden\r\n");
			break;
		case 404:
			strcpy(buf, " 404 Not Found\r\n");
			break;
		case 500:
			strcpy(buf, " 500 Internal Server Error\r\n");
	}

	return buf;
}


// 添加连接到队列
void ta_add_conn2queue(ta_conn_t *conn)
{
	ta_conn_node_t *nodep;
	time_t time_expire;

	nodep = queue.buf + conn->fd;	// 以fd为偏移量
	time_expire = time(NULL) + EXPIRE;
	conn->expire = time_expire;
	if(queue.cnt == 0)
	{
		nodep->previous = NULL;
		nodep->follow = NULL;
		nodep->conn = conn;
		queue.front = nodep;
		queue.rear = nodep;
		queue.cnt++;
	}
	else
	{
		nodep->previous = queue.rear;
		nodep->follow = NULL;
		nodep->conn = conn;
		queue.rear = nodep;
		queue.cnt++;
	}
}