#include <unistd.h>
#include <string.h>
#include <stdio.h>
#include <stdlib.h>
#include <getopt.h>
#include <regex.h>
#include <math.h>
#include "ta_conf.h"
#include "ta_misc.h"

//配置文件选项
static struct option longopt[] = {
		{"port",		required_argument,			NULL, 	'p'},
		{"nps",			required_argument,			NULL,	'n'},
		{"help",		no_argument,				NULL,	'h'},
		{"version",		no_argument,				NULL,	'v'},
		{0,				0,							0,		0}
};


// 显示usage
static void ta_usage()
{
	fprintf(stderr,
		"---------- talon [option] ----------\n"
		"		-p | --port      Set port\n"
		"		-n | --nps       Set work process number\n"
		"		-h | --help      Show help information\n"
		"		-v | --version   Show version\n"
		"------------------------------------\n"
		);
	exit(EXIT_SUCCESS);
}

// 显示版本号
static void ta_version()
{
	fprintf(stderr, "%s\n", VERSION);
	exit(EXIT_SUCCESS);
}

//从文件中读取配置
void ta_file_conf(char *fpath, ta_conf_t *cp)
{
	char line[MAXLINE];
	char *pattern= "^[[:space:]]*([[:alpha:]]+)[[:space:]]*=[[:space:]]*([.]?/?[[:alnum:]]+)[[:space:]]*[\r]?$";	// 匹配内容行
	char *key = NULL, *value = NULL;
	FILE *fp;
	regex_t reg;
	int err, hash, n = 4;
	regmatch_t pmatch[n];
	
	// 打开配置文件
	if( (fp = fopen(fpath, "r")) == NULL )
		ta_unix_err("Open configure file \"./conf/talon.conf\" failed");
	
	// 编译正则模式
	if( (err = regcomp(&reg, pattern, REG_EXTENDED | REG_ICASE | REG_NEWLINE)) )
	{
		regerror(err, &reg, line, MAXLINE);
		ta_app_err(line);
	}
	
	// 循环逐个读取配置文件内容	
	while( !feof(fp) )
	{

		/**
		 * 坑爹的fgets()
		 * fgets()失败或读到文件结尾返回NULL
		 * 因此我们不能直接通过fgets的返回值来判断函数是否是出错而终止的
		 * 应该借助feof函数或者ferror函数来判断
		 */
		/***********************************
		if( fgets(line, MAXLINE, fp) == NULL)
				ta_app_err("Read configure file failed");
		***********************************/

		if( fgets(line, MAXLINE, fp) == NULL)
			if(ferror(fp))
				ta_app_err("Read configure file failed");

		// 进行模式匹配
		if( regexec(&reg, line, n, pmatch, 0) == REG_NOMATCH ) 
			continue;
		// fprintf(stderr, "%d - %s", strlen(line), line);

		key = line + pmatch[1].rm_so;
		line[pmatch[1].rm_eo] = 0;
		value = line + pmatch[2].rm_so;
		line[pmatch[2].rm_eo] = 0;
		ta_str2lower(key);
		ta_str2lower(value);
		hash = INT(key);
		if(hash == INT("doc"))
		{
			memcpy(cp->doc, value, strlen(value) + 1);
		}
		else if(hash == INT("cgi"))
		{
			memcpy(cp->cgi, value, strlen(value) + 1);
		}
		else if(hash == INT("port"))
		{
			cp->port = abs(atoi(value));
		}
		else if(hash == INT("nps"))
		{
			cp->nps = abs(atoi(value)) > MAXWORKER ? MAXWORKER : abs(atoi(value));
		}		
	}
	regfree(&reg);
	fclose(fp);
}

// 从命令行读取配置
void ta_cmd_conf(int ac, char *av[], ta_conf_t *cp)
{

	int opt, tmp;	
	
	// 解析命令行
	optind = 1;
	while( (opt = getopt_long(ac, av, OPTSTRING, longopt, NULL)) != -1 )
	{
		switch(opt)
		{
			case 'p':
				cp->port = abs(atoi(optarg));
				break;
			case 'n':
				cp->nps = abs(atoi(optarg)) > MAXWORKER ? MAXWORKER : abs(atoi(optarg));	
				break;
			case 'h':
				ta_usage();
				exit(EXIT_SUCCESS);
			case 'v':
				ta_version();
				break;
			default:
				ta_usage();
				exit(EXIT_SUCCESS);
		}
	}
}

// 打印配置变量内容
void ta_debug_conf(ta_conf_t *cp)
{
	fprintf(stderr, "cp->doc = %s\n", cp->doc);
	fprintf(stderr, "cp->cgi = %s\n", cp->cgi);
	fprintf(stderr, "cp->port = %d\n", cp->port);
	fprintf(stderr, "cp->nps = %d\n", cp->nps);
	exit(EXIT_SUCCESS);
}
